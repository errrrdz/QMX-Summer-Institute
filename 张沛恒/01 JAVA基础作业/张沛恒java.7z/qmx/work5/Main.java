package com.qmx.work5;

public class Main {
    public static int method(String str, int index){
        int a[] = {1, 2, 3};
        try {
            System.out.println("字母是：" + str.charAt(index));
            System.out.println("数字是：" + a[index]);
        }
        catch (StringIndexOutOfBoundsException e){
            return 1;
        }
        catch (IndexOutOfBoundsException e){
            return 0;
        }

        return 2;
    }

    public static void main(String[] args) {

        String s = "abcdefg";

        System.out.println(method(s, 1));
        System.out.println(method(s, 10));
        System.out.println(method(s, 5));

    }
}
