package com.qmx.work2;

public class Main {
    public static void main(String[] args) {
        Circle  circle = new Circle(1.0);
        Cone cone = new Cone(1.0, 1.0);
        Ball ball = new Ball(1.0);

        System.out.println(circle.getArea());
        System.out.println(cone.getValue());
        System.out.println(ball.GetValue());

        circle.setR(2.0);
        cone.setR(2.0);
        cone.setHigh(2.0);
        ball.setR(2.0);

        System.out.println(circle.getArea());
        System.out.println(cone.getValue());
        System.out.println(ball.GetValue());

    }
}
