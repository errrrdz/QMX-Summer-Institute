package com.qmx.work2;

import java.lang.Math;

public class Ball extends Circle {
    protected double r;

    public Ball(){
        this.r = 0;
    }

    public Ball(double r){
        this.r = r;
    }

    public double GetValue(){
        return (4.0 / 3.0) * Math.PI  * this.r * this.r * this.r;
    }
}
