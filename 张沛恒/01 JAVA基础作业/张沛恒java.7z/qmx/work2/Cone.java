package com.qmx.work2;

public class Cone extends Circle {
    protected double r;

    protected double high;

    public Cone(){
        this.r = 0;
        this.high = 0;
    }

    public Cone(double r, double high){
        this.r = r;
        this.high = high;
    }

    public void setHigh(double h){
        this.high = h;
    }

    public double getHigh(){
        return this.high;
    }

    public double getArea(){ return (this.r * this.r * Math.PI); }

    public double getValue(){
        return (this.getArea() * this.high);
    }
}
