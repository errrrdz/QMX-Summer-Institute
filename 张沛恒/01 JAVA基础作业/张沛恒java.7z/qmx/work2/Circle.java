package com.qmx.work2;

import java.lang.Math;

public class Circle {
    protected double r;

    public Circle(){
        this.r = 0;
    }

    public Circle(double r){
        this.r = r;
    }

    public void setR(double r){
        this.r = r;
    }

    public double getR(){
        return this.r;
    }

    public double getArea(){
        return (Math.PI * this.r * this.r);
    }
}
