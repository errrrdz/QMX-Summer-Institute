package com.qmx.work3;

public class Rectiangle extends Shape {
    private double l;
    private double w;
    private double area;
    private double perimeter;


    public Rectiangle(double l, double w){
        setL(l);
        setW(w);
    }

    public void setL(double l){
        this.l = l;
    }

    public void setW(double w){
        this.w = w;
    }

    public double getArea() {
        this.area = (w * l);
        return this.area;
    }

    public double getperimeter() {
        this.perimeter = (2 * (l * w));
        return this.perimeter;
    }
}
