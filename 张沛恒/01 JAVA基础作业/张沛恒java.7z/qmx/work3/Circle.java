package com.qmx.work3;

public class Circle extends Shape {
    private double area;
    private double perimeter;
    private double r;

    public Circle(double r){
        this.setR(r);
    }

    public void setR(double r){
        this.r = r;
        this.area = (Math.PI * Math.pow(this.r, 2));
        this.perimeter = (Math.PI * 2 * this.r);
    }

    public double getArea() {
        return this.area;
    }

    public double getperimeter(){
        return this.perimeter;
    }
}
