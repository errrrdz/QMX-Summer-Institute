package com.qmx.work3;

public class Main {
    public static void main(String[] args) {
        Rectiangle r = new Rectiangle(2, 2);
        Circle c = new Circle(2);

        System.out.println(c.getArea());
        System.out.println(c.getperimeter());
        System.out.println(r.getArea());
        System.out.println(r.getperimeter());

        r.setW(3);
        r.setL(3);
        c.setR(3);

        System.out.println(c.getArea());
        System.out.println(c.getperimeter());
        System.out.println(r.getArea());
        System.out.println(r.getperimeter());
    }
}
