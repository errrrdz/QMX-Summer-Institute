package com.qmx.work3;

public abstract class Shape {
    private double area;
    private double perimeter;

    public Shape(){

    }

    public double getArea(){ return this.area; }

    public double getperimeter(){ return this.perimeter; }

}
