package com.qmx.work6;

public class Dog implements Animal {

    private String name = "Dog";

    public void cry(){
        System.out.println(this.getAnimalName() + " cry.");
    };

    public String getAnimalName(){
        return this.name;
    };

}
