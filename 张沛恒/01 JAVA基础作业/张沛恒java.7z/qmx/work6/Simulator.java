package com.qmx.work6;

public class Simulator implements Animal {
    private String name;
    
    public void playSound(Animal animal){
        animal.getAnimalName();
        animal.cry();
    }

    public void cry() {
        System.out.println("Name:" + getAnimalName() + " cry.");
    }

    public String getAnimalName() {
        return this.name;
    }
}
