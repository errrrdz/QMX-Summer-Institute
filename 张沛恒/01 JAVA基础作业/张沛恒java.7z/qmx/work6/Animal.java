package com.qmx.work6;

public interface Animal {
    public void cry();
    public String getAnimalName();
}
