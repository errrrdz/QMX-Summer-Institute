package com.qmx.work6;

public class Cat implements Animal {

    private String name = "Cat";

    public void cry(){
        System.out.println(this.getAnimalName() + " cry.");
    };

    public String getAnimalName(){
        return this.name;
    };

}
