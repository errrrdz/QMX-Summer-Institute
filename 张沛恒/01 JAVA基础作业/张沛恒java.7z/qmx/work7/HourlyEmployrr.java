package com.qmx.work7;

public class HourlyEmployrr extends Employee {
    private double wage;
    private double hour;

    public HourlyEmployrr(String string, int number, MyDate date, double hour, double wage){
        super(string, number, date);
        this.wage = wage;
        this.hour = hour;
    }

    public double getPrice(){
        return (wage * hour);
    }

    public double earning(){
        return (wage * hour);
    }

    public String toString(){
        System.out.println("Name:" + getName() + " Number:" + getNumber() + " Birthday:" + getBirthday());
        return "Name:" + getName() + " Number:" + getNumber() + " Birthday:" + getBirthday();
    }

    public void pay(MyDate date){
        System.out.print("The price is " + getPrice() + " .");

        if ((this.getBirthday().getMonth() == date.getMonth()) && (this.getBirthday().getDay() == date.getDay())){
            System.out.print("And today is it's birthday so he can get 100 more");
        }

        System.out.println(".");
    }
}
