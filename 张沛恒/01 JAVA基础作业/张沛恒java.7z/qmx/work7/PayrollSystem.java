package com.qmx.work7;

public class PayrollSystem {

    public static void main(String[] args) {
        MyDate[] d = new MyDate[5];
        Employee[] p = new Employee[5];
        MyDate today = new MyDate(2021, 3, 9);

        d[0] = new MyDate(2002, 3, 9);
        d[1] = new MyDate(1875, 1, 1);
        d[2] = new MyDate(1000, 1, 1);
        d[3] = new MyDate(1995, 3, 9);
        d[4] = new MyDate(1000, 5, 5);

        p[0] = new HourlyEmployrr("zph", 0, d[0], 10, 100);
        p[1] = new HourlyEmployrr("phz", 1,d[1], 1,10000);
        p[2] = new SalariedEmployee("pph", 2, d[2], 100000);
        p[3] = new SalariedEmployee("php", 3, d[3], 9999999);
        p[4] = new SalariedEmployee("hpp", 4, d[4], 1);

        for (int i = 0; i < 5; i++){
            p[i].pay(today);
        }

    }

}
