package com.qmx.work7;

public abstract class Employee {
    private String name;
    private int number;
    private MyDate birthday;

    public Employee(String name, int number, MyDate birthday){
        this.name = name;
        this.number = number;
        this.birthday = birthday;
    }

    public String getName(){
        return this.name;
    }

    public int getNumber(){
        return this.number;
    }

    public MyDate getBirthday(){
        return this.birthday;
    }

    public abstract double earning();

    public String toString(){
        System.out.println("name:" + this.name + " number:" + this.number + "birthday:" + this.birthday.toDateString());
        return "name:" + this.name + " number:" + this.number + "birthday:" + this.birthday.toDateString();
    }

    public void pay(MyDate date){

    }
}
