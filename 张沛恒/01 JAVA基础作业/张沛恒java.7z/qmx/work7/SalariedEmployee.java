package com.qmx.work7;

public class SalariedEmployee extends Employee {

    private double monthlySalary;

    public SalariedEmployee(String string, int number, MyDate date, double monthlySalary){
        super(string, number, date);
        this.monthlySalary = monthlySalary;
    }

    public double getMonthlySalary(){
        return this.monthlySalary;
    }

    public double earning(){

        return this.monthlySalary;
    }

    public String toString(){
        System.out.println("Name:" + getName() + " Number:" + getNumber() + " Birthday:" + getBirthday());
        return "Name:" + getName() + " Number:" + getNumber() + " Birthday:" + getBirthday();
    }

    public void pay(MyDate date){
        System.out.print("The price is " + getMonthlySalary() + " .");

        if (this.getBirthday().getMonth() == date.getMonth()){
            System.out.print("And today is it's birthday so he can get 100 more!");
        }

        System.out.println(".");
    }

}
