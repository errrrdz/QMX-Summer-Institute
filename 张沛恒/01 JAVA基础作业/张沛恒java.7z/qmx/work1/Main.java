package com.qmx.work1;

public class Main {
    public static void main(String[] args) {
        Gcd a = new Gcd(4, 2);
        Lcm b = new Lcm(4, 2);

        int gCD = a.f(a.getA(), a.getB());
        int lCM = b.f(b.getA(), b.getB());

        System.out.println("GCD = " + gCD);
        System.out.println("LCM = " + lCM);
    }
}

