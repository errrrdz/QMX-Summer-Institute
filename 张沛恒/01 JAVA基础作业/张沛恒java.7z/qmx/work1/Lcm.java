package com.qmx.work1;

public class Lcm extends Gcd {
    public Lcm(int a, int b){
        super(a, b);
    }
    public int f(int a, int b){
        return ((a * b) / super.f(a, b));
    }
}
