package com.qmx.work1;

public class Gcd {
    private int a;
    private int b;

    public Gcd(int a, int b){
        this.a = a;
        this.b = b;
    }

    public int getA(){
        return this.a;
    }

    public int getB(){
        return this.b;
    }

    public int f(int a, int b){
        int r;
        while(b > 0){
            r=a%b;
            a=b;
            b=r;
        }
        return a;
    }
}
