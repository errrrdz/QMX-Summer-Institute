package com.qmx.work4;

import java.util.ArrayList; // 引入 ArrayList 类
public class Main {
    public static void main(String[] args) {
        ArrayList<String> sites = new ArrayList<String>();
        sites.add("A");
        sites.add("B");
        sites.add("C");
        sites.add("D");

        System.out.println("sites中的元素为：" + sites);

        System.out.println("使用get方法for循环遍历:");
        for (int i = 0; i < 4; i++){
            System.out.println(sites.get(i));
        }

        System.out.println("使用for-each语法遍历:");
        for (String i : sites) {
            System.out.println(i);
        }

        System.out.println("使用forEach方法遍历:");
        sites.forEach((e) -> {
            System.out.println(e);
        });
    }
}
